<?php

return [

	/*
	|--------------------------------------------------------------------------
	| Autenticación de líneas de lenguaje
	|--------------------------------------------------------------------------
	|
  | Las siguientes líneas de idioma se utilizan durante la autenticación para varios
  | Mensajes que necesitamos mostrar al usuario. Eres libre de modificar
  | Estas líneas lingüísticas de acuerdo a los requisitos de su aplicación.
	|
	*/

    'failed' => 'Las credenciales introducidas son incorrectas.',
    'inactive' => 'La cuenta ha sido deshabilitada',
    'throttle' => 'La cuenta ha sido bloqueada, contáctese con el administrador del sistema',
    'unknown' => 'Las credenciales introducidas son incorrectas'
];
