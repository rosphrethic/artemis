setTimeout(() => {
    $(".loader_bg").fadeToggle();
}, 800);
